import asyncio
import os
import sys
import signal
import tornado.ioloop
import tornado.platform.asyncio
from datetime import datetime
from pyrogram import Client, filters
from PyroUbot import *

# --- HANDLER RESTART (NAMA & ID SESUAI PENGIRIM) ---
@bot.on_message(filters.command("restart"))
async def restart_bot_utama(client, message):
    pengirim_name = message.from_user.first_name
    pengirim_id = message.from_user.id

    status = await message.reply("<b>ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ</b>")
    
    await asyncio.sleep(2)
    
    await status.edit(
        f"<b>ʀᴇsᴛᴀʀᴛ ʙᴇʀʜᴀsɪʟ ᴅɪʟᴀᴋᴜᴋᴀɴ !</b>\n\n"
        f"<b>ɴᴀᴍᴇ:</b> {pengirim_name} | <code>{pengirim_id}</code>"
    )
    
    os.execl(sys.executable, sys.executable, "-m", "PyroUbot")

async def shutdown(signal, loop):
    print(f"Received exit signal {signal.name}...")
    tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
    [task.cancel() for task in tasks]
    print("Cancelling outstanding tasks")
    await asyncio.gather(*tasks, return_exceptions=True)
    loop.stop()

# --- FUNGSI NOTIFIKASI STARTUP ---
async def send_log_startup():
    await asyncio.sleep(5) 
    ID_LOG_CHANNEL = -1003841423220 
    
    if ubot._ubot:
        akun_utama = ubot._ubot[0]
        try:
            text_start = (
                f"<b>ᴍʏ ᴜʙᴏᴛ ᴘʀᴇᴍɪᴜᴍ</b>\n"
                f"<b>❑ ᴜsᴇʀʙᴏᴛ ᴅɪᴀᴋᴛɪғᴋᴀɴ</b>\n"
                f"<b>├ ᴀᴋᴜɴ: {akun_utama.me.first_name}</b>\n"
                f"<b>└ ɪᴅ: <code>{akun_utama.me.id}</code></b>"
            )
            await bot.send_message(ID_LOG_CHANNEL, text_start)
        except Exception as e:
            print(f"Gagal kirim log ke CH: {e}")

# ==================== FITUR BARU: NOTIF ORDER SUKSES ====================

async def send_order_success_notification(user_id, username, order_id, role, duration):
    """
    Kirim notifikasi ke channel LOG saat user berhasil membuat/beli userbot
    """
    ID_LOG_CHANNEL = -1003841423220  # Ganti dengan channel ID lo
    
    waktu = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    
    notif_text = f"""<blockquote><b>✅ ORDER USERBOT SUKSES !!!</b>

<b>🛍️ DETAIL ORDER:</b>
<b>├ 👤 USER:</b> <a href='tg://user?id={user_id}'>{username}</a>
<b>├ 🆔 USER ID:</b> <code>{user_id}</code>
<b>├ 📦 ORDER ID:</b> <code>{order_id}</code>
<b>├ 🎫 ROLE:</b> {role}
<b>├ 📆 DURASI:</b> {duration}
<b>└ ⏰ WAKTU:</b> {waktu}

<b>🎉 SELAMAT! USER BERHASIL MEMBUAT USERBOT</b></blockquote>"""
    
    try:
        await bot.send_message(ID_LOG_CHANNEL, notif_text)
        print(f"[NOTIF] Order sukses dikirim ke channel untuk user {user_id}")
    except Exception as e:
        print(f"[ERROR] Gagal kirim notifikasi order: {e}")

async def notify_owner_new_order(user_id, username, order_id):
    """
    Kirim notifikasi ke OWNER saat ada order baru (opsional)
    """
    from config import OWNER_ID
    
    notif_text = f"""<blockquote><b>🛍️ ORDER USERBOT BARU!</b>

<b>👤 USER:</b> <a href='tg://user?id={user_id}'>{username}</a>
<b>🆔 ID:</b> <code>{user_id}</code>
<b>📦 ORDER ID:</b> <code>{order_id}</code>

<b>⏳ MENUNGGU KONFIRMASI PEMBAYARAN</b></blockquote>"""
    
    try:
        await bot.send_message(OWNER_ID, notif_text)
    except Exception as e:
        print(f"[ERROR] Gagal kirim notif ke owner: {e}")

# ==================== MAIN FUNCTION ====================

async def main():
    await bot.start()
    
    # Kirim notif startup ke LOG channel
    ID_LOG_CHANNEL = -1003841423220
    try:
        await bot.send_message(
            ID_LOG_CHANNEL,
            "<blockquote><b>🤖 BOT ZEXC PREMIUM STARTED</b>\n\n"
            f"<b>⏰ WAKTU:</b> {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}\n"
            f"<b>✅ STATUS:</b> ONLINE</blockquote>"
        )
    except:
        pass
    
    for _ubot in await get_userbots():
        ubot_ = Ubot(**_ubot)
        try:
            await asyncio.wait_for(ubot_.start(), timeout=10)
            
            # Kirim notif setiap userbot berhasil start
            try:
                await bot.send_message(
                    ID_LOG_CHANNEL,
                    f"<blockquote><b>🚀 USERBOT AKTIF</b>\n\n"
                    f"<b>👤 AKUN:</b> {ubot_.me.first_name}\n"
                    f"<b>🆔 ID:</b> <code>{ubot_.me.id}</code></blockquote>"
                )
            except:
                pass
                
        except asyncio.TimeoutError:
            await remove_ubot(int(_ubot["name"]))
            print(f"[ɪɴғᴏ]: {int(_ubot['name'])} ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇʀᴇsᴘᴏɴ")
        except Exception:
            await remove_ubot(int(_ubot["name"]))
            print(f"[ɪɴғᴏ]: {int(_ubot['name'])} ʙᴇʀʜᴀsɪʟ ᴅɪ ʜᴀᴘᴜs")
    
    await bash("rm -rf *session*")
    
    await asyncio.gather(loadPlugins(), installPeer(), expiredUserbots())
    
    asyncio.create_task(send_log_startup())
    
    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for s in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            s, lambda: asyncio.create_task(shutdown(s, loop))
        )

    try:
        await stop_event.wait()
    except asyncio.CancelledError:
        pass
    finally:
        await bot.stop()

if __name__ == "__main__":
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = tornado.ioloop.IOLoop.current().asyncio_loop
    loop.run_until_complete(main())